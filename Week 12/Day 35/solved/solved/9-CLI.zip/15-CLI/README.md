# **Instructions**

* Implement the logic for the CLI component. Refer to the architectural diagram for help.

  * Before you write any JavaScript, write out the CLI component's behavior in pseudocode.

  * Be sure to require the `WeatherAdmin` module here.

  * When you're finished, ask the instructor or one of your TAs to approve your solution.

  * **Hint**: This component doesn't require much code.
