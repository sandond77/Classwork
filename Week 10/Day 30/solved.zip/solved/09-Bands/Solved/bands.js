var myBands = {
  punk: "Green Day",
  rap: "Run DMC",
  classic: "Led Zeppelin"
};


module.exports = myBands;