# Sriracha

## File

* *None*

## Instructions

* Create a file called `sriracha.js` somewhere on your computer.

* Inside the file use JavaScript to log the words: "Sriracha. Goes great on.... nothing." (or everything. You choose.)

* Then run the program using Node in your terminal/bash window.

* Confirm that it logged the text as you would expect.
